
    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center bottom-separator">
                    <img src="images/home/under.png" class="img-responsive inline" alt="">
                </div>
                <div class="col-md-3 col-sm-6">
                    
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="contact-info bottom">
                        <h2><b>Tentang</b></h2>
                        <address>
                        E-mail: <a href="mailto:govindo1706@gmail.com">govindo1706@gmail.com</a> <br> 
                        Phone: 0812-8718-9069 <br> 
                        Sosial Media : gofindo.17 <br> <br>
                        </address>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="contact-info bottom">
                        <h2><b>Institusi</b></h2>
                        <address>
                        Universitas Nusa Putra Sukabumi, <br> 
                        Pengembangan Aplikasi Berbasis Web, <br> 
                        Teknik Informatika `19  <br> 
                        <br>
                        </address>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="copyright-text text-center">
                        <p>&copy; Pariwisata Danau Toba 2021 | <a href="../back/index.php">by Berniman Gofindo Malau</a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--/#footer-->

    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/lightbox.min.js"></script>
    <script type="text/javascript" src="js/wow.min.js"></script>
    <script type="text/javascript" src="js/main.js"></script>  

    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="js/gmaps.js"></script>
    
</body>
</html>
